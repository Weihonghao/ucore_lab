#ifndef __KERN_SYSCALL_SYSCALL_H__
#define __KERN_SYSCALL_SYSCALL_H__

void syscall(void);

#endif /* !__KERN_SYSCALL_SYSCALL_H__ */

